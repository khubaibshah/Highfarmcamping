/*
const mysql = require('../db/mysql');


exports.select = function yes() {

    mysql.connection.query("SELECT  * FROM customers ORDER BY customer_id;", function(err, rows) {
        console.log(rows);
        return rows;
    });

}
*/

//TODO CREATE Function


//TODO READ Function

//TODO UPDATE Function

//TODO DELETE Function

